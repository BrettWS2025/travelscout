export const products = [
  { name: "Wise Travel Card", fxFee: "0.35%–1.0%", atm: "$0–$1.50", perks: "Mid‑market rates", url: "#" },
  { name: "Air NZ Travel Card", fxFee: "1.85%", atm: "$3", perks: "Airpoints earn", url: "#" },
  { name: "Travelex Money Card", fxFee: "Varies", atm: "$3.50", perks: "Locked‑in rates", url: "#" },
];
