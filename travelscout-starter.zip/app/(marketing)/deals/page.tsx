export const metadata = { title: "Deals" };
export default function Deals() {
  return (
    <section className="space-y-4">
      <h1 className="text-3xl font-bold">Deals</h1>
      <p className="text-[var(--muted)]">Verified travel deals and mistake fares with clear 'gotchas'.</p>
      <div className="grid md:grid-cols-3 gap-4">
        {Array.from({length:6}).map((_,i)=> (
          <article key={i} className="card p-4">
            <div className="badge">Limited</div>
            <h3 className="mt-2 text-xl font-semibold">Sample deal #{i+1}</h3>
            <p className="text-[var(--muted)]">AKL ✈ SYD return from $299</p>
            <a className="link" href="#">See details</a>
          </article>
        ))}
      </div>
    </section>
  );
}
