// Minimal declaration so TypeScript is happy importing this JS-only plugin.
declare module "leaflet-routing-machine";
