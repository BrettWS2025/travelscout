export async function GET() {
  return Response.json({ ok: true, message: "Hello from TravelScout API" });
}
