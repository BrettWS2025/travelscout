# TravelScout (Stable Starter)

Pinned, compatible versions so Vercel builds cleanly.

## Versions
- Next 14.2.5
- React 18.2
- Tailwind 3.4.x + PostCSS 8.4.x + Autoprefixer 10.4.x

## Run
npm install
npm run dev

## Deploy
Import to Vercel (Build: `next build`, Output: `.next`).
